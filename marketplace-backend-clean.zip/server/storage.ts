import { 
  customers, 
  products, 
  orders, 
  orderItems,
  type Customer, 
  type InsertCustomer,
  type Product,
  type InsertProduct,
  type Order,
  type InsertOrder,
  type OrderItem,
  type InsertOrderItem,
  type OrderWithDetails,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, gte } from "drizzle-orm";

export interface IStorage {
  // Customers
  getCustomer(id: string): Promise<Customer | undefined>;
  getCustomerByEmail(email: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  getAllCustomers(): Promise<Customer[]>;
  
  // Products
  getProduct(id: string): Promise<Product | undefined>;
  getProductBySku(sku: string, marketplace: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  getAllProducts(): Promise<Product[]>;
  
  // Orders
  getOrder(id: string): Promise<OrderWithDetails | undefined>;
  getOrderByExternalId(externalId: string, marketplace: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  getAllOrders(): Promise<OrderWithDetails[]>;
  getRecentOrders(limit: number): Promise<OrderWithDetails[]>;
  getOrdersToday(): Promise<Order[]>;
  
  // Order Items
  createOrderItem(item: InsertOrderItem): Promise<OrderItem>;
  getOrderItems(orderId: string): Promise<OrderItem[]>;
  
  // Analytics
  getDashboardMetrics(): Promise<any>;
  getFaturamento(): Promise<any>;
  getTopProdutos(limit: number): Promise<any[]>;
  getMenosVendidos(limit: number): Promise<any[]>;
  getVendasPorEstado(): Promise<any[]>;
  getCustomersWithStats(): Promise<any[]>;
}

export class DatabaseStorage implements IStorage {
  // Customers
  async getCustomer(id: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.id, id));
    return customer || undefined;
  }

  async getCustomerByEmail(email: string): Promise<Customer | undefined> {
    const [customer] = await db.select().from(customers).where(eq(customers.email, email));
    return customer || undefined;
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const [customer] = await db
      .insert(customers)
      .values(insertCustomer)
      .returning();
    return customer;
  }

  async getAllCustomers(): Promise<Customer[]> {
    return await db.select().from(customers).orderBy(desc(customers.createdAt));
  }

  // Products
  async getProduct(id: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async getProductBySku(sku: string, marketplace: string): Promise<Product | undefined> {
    const [product] = await db.select().from(products)
      .where(and(eq(products.skuNormalizado, sku), eq(products.marketplace, marketplace)));
    return product || undefined;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db
      .insert(products)
      .values(insertProduct)
      .returning();
    return product;
  }

  async updateProduct(id: string, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const [product] = await db
      .update(products)
      .set({ ...updateData, lastSync: new Date() })
      .where(eq(products.id, id))
      .returning();
    return product || undefined;
  }

  async getAllProducts(): Promise<Product[]> {
    return await db.select().from(products).orderBy(desc(products.lastSync));
  }

  // Orders
  async getOrder(id: string): Promise<OrderWithDetails | undefined> {
    const [order] = await db.query.orders.findMany({
      where: eq(orders.id, id),
      with: {
        customer: true,
        items: {
          with: {
            product: true,
          },
        },
      },
      limit: 1,
    });
    return order as OrderWithDetails | undefined;
  }

  async getOrderByExternalId(externalId: string, marketplace: string): Promise<Order | undefined> {
    const [order] = await db.select().from(orders)
      .where(and(eq(orders.externalOrderId, externalId), eq(orders.marketplace, marketplace)));
    return order || undefined;
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const [order] = await db
      .insert(orders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async getAllOrders(): Promise<OrderWithDetails[]> {
    const result = await db.query.orders.findMany({
      with: {
        customer: true,
        items: {
          with: {
            product: true,
          },
        },
      },
      orderBy: desc(orders.orderDate),
    });
    return result as OrderWithDetails[];
  }

  async getRecentOrders(limit: number): Promise<OrderWithDetails[]> {
    const result = await db.query.orders.findMany({
      with: {
        customer: true,
        items: {
          with: {
            product: true,
          },
        },
      },
      orderBy: desc(orders.orderDate),
      limit,
    });
    return result as OrderWithDetails[];
  }

  async getOrdersToday(): Promise<Order[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    return await db.select().from(orders)
      .where(gte(orders.orderDate, today));
  }

  // Order Items
  async createOrderItem(insertItem: InsertOrderItem): Promise<OrderItem> {
    const [item] = await db
      .insert(orderItems)
      .values(insertItem)
      .returning();
    return item;
  }

  async getOrderItems(orderId: string): Promise<OrderItem[]> {
    return await db.select().from(orderItems)
      .where(eq(orderItems.orderId, orderId));
  }

  // Analytics
  async getDashboardMetrics() {
    try {
      const allOrders = await db.select().from(orders);
      const ordersToday = await this.getOrdersToday();
      const allProducts = await db.select().from(products);
      const allCustomers = await db.select().from(customers);

      const totalRevenue = allOrders.reduce((sum, order) => {
        const amount = parseFloat(order.totalAmount.toString());
        return sum + (isNaN(amount) ? 0 : amount);
      }, 0);

      return {
        totalRevenue,
        ordersToday: ordersToday.length,
        activeProducts: allProducts.length,
        totalCustomers: allCustomers.length,
      };
    } catch (error) {
      return {
        totalRevenue: 0,
        ordersToday: 0,
        activeProducts: 0,
        totalCustomers: 0,
      };
    }
  }

  async getFaturamento() {
    try {
      const allOrders = await db.select().from(orders);
      
      const total = allOrders.reduce((sum, order) => {
        const amount = parseFloat(order.totalAmount.toString());
        return sum + (isNaN(amount) ? 0 : amount);
      }, 0);
      
      const marketplaceMap = new Map<string, { total: number; ordersCount: number }>();
      allOrders.forEach(order => {
        const current = marketplaceMap.get(order.marketplace) || { total: 0, ordersCount: 0 };
        const amount = parseFloat(order.totalAmount.toString());
        marketplaceMap.set(order.marketplace, {
          total: current.total + (isNaN(amount) ? 0 : amount),
          ordersCount: current.ordersCount + 1,
        });
      });

      const byMarketplace = Array.from(marketplaceMap.entries()).map(([marketplace, data]) => ({
        marketplace,
        total: data.total,
        ordersCount: data.ordersCount,
      }));

      return { total, byMarketplace };
    } catch (error) {
      return { total: 0, byMarketplace: [] };
    }
  }

  async getTopProdutos(limit: number) {
    try {
      const items = await db.select().from(orderItems);
      const productsData = await db.select().from(products);
      
      const productMap = new Map<string, { 
        productId: string; 
        productName: string; 
        marketplace: string;
        unitsSold: number; 
        revenue: number 
      }>();

      for (const item of items) {
        if (!item.productId) continue;
        const product = productsData.find(p => p.id === item.productId);
        if (!product) continue;

        const current = productMap.get(item.productId) || {
          productId: product.id,
          productName: product.name,
          marketplace: product.marketplace,
          unitsSold: 0,
          revenue: 0,
        };

        const price = parseFloat(item.totalPrice.toString());
        productMap.set(item.productId, {
          ...current,
          unitsSold: current.unitsSold + item.quantity,
          revenue: current.revenue + (isNaN(price) ? 0 : price),
        });
      }

      return Array.from(productMap.values())
        .sort((a, b) => b.unitsSold - a.unitsSold)
        .slice(0, limit);
    } catch (error) {
      return [];
    }
  }

  async getMenosVendidos(limit: number) {
    try {
      const items = await db.select().from(orderItems);
      const productsData = await db.select().from(products);
      
      const productMap = new Map<string, { 
        productId: string; 
        productName: string; 
        marketplace: string;
        unitsSold: number; 
        revenue: number 
      }>();

      for (const item of items) {
        if (!item.productId) continue;
        const product = productsData.find(p => p.id === item.productId);
        if (!product) continue;

        const current = productMap.get(item.productId) || {
          productId: product.id,
          productName: product.name,
          marketplace: product.marketplace,
          unitsSold: 0,
          revenue: 0,
        };

        const price = parseFloat(item.totalPrice.toString());
        productMap.set(item.productId, {
          ...current,
          unitsSold: current.unitsSold + item.quantity,
          revenue: current.revenue + (isNaN(price) ? 0 : price),
        });
      }

      return Array.from(productMap.values())
        .sort((a, b) => a.unitsSold - b.unitsSold)
        .slice(0, limit);
    } catch (error) {
      return [];
    }
  }

  async getVendasPorEstado() {
    try {
      const allOrders = await db.select().from(orders);
      const allCustomers = await db.select().from(customers);
      
      const stateMap = new Map<string, { 
        ordersCount: number;
        totalRevenue: number;
        customerIds: Set<string>;
      }>();

      for (const order of allOrders) {
        if (!order.customerId) continue;
        const customer = allCustomers.find(c => c.id === order.customerId);
        if (!customer || !customer.state) continue;

        const current = stateMap.get(customer.state) || {
          ordersCount: 0,
          totalRevenue: 0,
          customerIds: new Set<string>(),
        };

        current.ordersCount += 1;
        const amount = parseFloat(order.totalAmount.toString());
        current.totalRevenue += isNaN(amount) ? 0 : amount;
        current.customerIds.add(customer.id);

        stateMap.set(customer.state, current);
      }

      return Array.from(stateMap.entries())
        .map(([state, data]) => ({
          state,
          ordersCount: data.ordersCount,
          totalRevenue: data.totalRevenue,
          customersCount: data.customerIds.size,
        }))
        .sort((a, b) => b.totalRevenue - a.totalRevenue);
    } catch (error) {
      return [];
    }
  }

  async getCustomersWithStats() {
    try {
      const allCustomers = await db.select().from(customers);
      const allOrders = await db.select().from(orders);
      
      return allCustomers.map(customer => {
        const customerOrders = allOrders.filter(o => o.customerId === customer.id);
        const totalSpent = customerOrders.reduce((sum, o) => {
          const amount = parseFloat(o.totalAmount.toString());
          return sum + (isNaN(amount) ? 0 : amount);
        }, 0);
        const lastOrder = customerOrders.length > 0 
          ? customerOrders.reduce((latest, o) => 
              new Date(o.orderDate) > new Date(latest.orderDate) ? o : latest
            )
          : null;

        return {
          ...customer,
          ordersCount: customerOrders.length,
          totalSpent: totalSpent.toString(),
          lastOrderDate: lastOrder ? lastOrder.orderDate.toISOString() : null,
        };
      }).sort((a, b) => Number(b.totalSpent) - Number(a.totalSpent));
    } catch (error) {
      return [];
    }
  }
}

export const storage = new DatabaseStorage();
