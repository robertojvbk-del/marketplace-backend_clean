import { logger } from "../utils/logger";

export interface LojaIntegradaOrder {
  id: string;
  numero: string;
  data_criacao: string;
  valor_total: string;
  situacao: {
    codigo: string;
    nome: string;
  };
  cliente: {
    nome: string;
    email: string;
    telefone_celular?: string;
    cpf?: string;
    endereco_entrega?: {
      estado: string;
    };
  };
  itens: {
    produto: {
      id: string;
      sku: string;
      nome: string;
    };
    quantidade: number;
    preco_venda: string;
    subtotal: string;
  }[];
}

export interface LojaIntegradaProduct {
  id: string;
  sku: string;
  nome: string;
  preco: string;
  estoque: number;
}

const mockOrders: LojaIntegradaOrder[] = [
  {
    id: "LI5001",
    numero: "5001",
    data_criacao: new Date().toISOString(),
    valor_total: "349.90",
    situacao: {
      codigo: "2",
      nome: "Em produção",
    },
    cliente: {
      nome: "Roberto Fernandes",
      email: "roberto@example.com",
      telefone_celular: "11999887766",
      cpf: "987.654.321-00",
      endereco_entrega: {
        estado: "SP",
      },
    },
    itens: [
      {
        produto: {
          id: "LI001",
          sku: "CAM-SPT-001",
          nome: "Câmera de Segurança WiFi",
        },
        quantidade: 1,
        preco_venda: "349.90",
        subtotal: "349.90",
      },
    ],
  },
  {
    id: "LI5002",
    numero: "5002",
    data_criacao: new Date(Date.now() - 432000000).toISOString(),
    valor_total: "129.90",
    situacao: {
      codigo: "5",
      nome: "Entregue",
    },
    cliente: {
      nome: "Juliana Costa",
      email: "juliana@example.com",
      endereco_entrega: {
        estado: "MG",
      },
    },
    itens: [
      {
        produto: {
          id: "LI002",
          sku: "LMP-LED-002",
          nome: "Lâmpada LED Inteligente",
        },
        quantidade: 3,
        preco_venda: "43.30",
        subtotal: "129.90",
      },
    ],
  },
];

const mockProducts: LojaIntegradaProduct[] = [
  {
    id: "LI001",
    sku: "CAM-SPT-001",
    nome: "Câmera de Segurança WiFi",
    preco: "349.90",
    estoque: 8,
  },
  {
    id: "LI002",
    sku: "LMP-LED-002",
    nome: "Lâmpada LED Inteligente",
    preco: "43.30",
    estoque: 45,
  },
];

export class LojaIntegradaService {
  private email: string;
  private apiKey: string;

  constructor() {
    this.email = process.env.LOJA_INTEGRADA_EMAIL || '';
    this.apiKey = process.env.LOJA_INTEGRADA_API_KEY || '';
  }

  async getOrders(): Promise<LojaIntegradaOrder[]> {
    try {
      if (!this.email || !this.apiKey) {
        logger.warn('Loja Integrada credentials not configured, using mock data');
        return mockOrders;
      }

      // Real API call would go here
      logger.info('Using Loja Integrada mock data for orders');
      return mockOrders;
    } catch (error) {
      logger.error('Error fetching Loja Integrada orders', error);
      return mockOrders;
    }
  }

  async getProducts(): Promise<LojaIntegradaProduct[]> {
    try {
      if (!this.email || !this.apiKey) {
        logger.warn('Loja Integrada credentials not configured, using mock data');
        return mockProducts;
      }

      logger.info('Using Loja Integrada mock data for products');
      return mockProducts;
    } catch (error) {
      logger.error('Error fetching Loja Integrada products', error);
      return mockProducts;
    }
  }
}
