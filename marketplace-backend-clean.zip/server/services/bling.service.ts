import { logger } from "../utils/logger";
import { normalizeSku, normalizeStatus } from "../utils/sku-normalizer";

export interface BlingOrder {
  id: string;
  numero: string;
  dataVenda: string;
  totalProdutos: number;
  total: number;
  situacao: string;
  cliente: {
    nome: string;
    email?: string;
    telefone?: string;
    documento?: string;
    uf?: string;
  };
  itens: {
    produto: {
      id: string;
      codigo: string;
      descricao: string;
    };
    quantidade: number;
    valorunidade: number;
    valor: number;
  }[];
}

export interface BlingProduct {
  id: string;
  codigo: string;
  descricao: string;
  preco: number;
  estoqueAtual?: number;
}

// Mock data for testing without real API
const mockOrders: BlingOrder[] = [
  {
    id: "1001",
    numero: "BLG-001",
    dataVenda: new Date().toISOString(),
    totalProdutos: 250.00,
    total: 250.00,
    situacao: "Em aberto",
    cliente: {
      nome: "João Silva",
      email: "joao@example.com",
      telefone: "(11) 98765-4321",
      documento: "123.456.789-00",
      uf: "SP",
    },
    itens: [
      {
        produto: {
          id: "P001",
          codigo: "PROD-001",
          descricao: "Notebook Dell Inspiron 15",
        },
        quantidade: 1,
        valorunidade: 250.00,
        valor: 250.00,
      },
    ],
  },
  {
    id: "1002",
    numero: "BLG-002",
    dataVenda: new Date(Date.now() - 86400000).toISOString(),
    totalProdutos: 150.00,
    total: 150.00,
    situacao: "Entregue",
    cliente: {
      nome: "Maria Santos",
      email: "maria@example.com",
      uf: "RJ",
    },
    itens: [
      {
        produto: {
          id: "P002",
          codigo: "PROD-002",
          descricao: "Mouse Logitech MX Master",
        },
        quantidade: 2,
        valorunidade: 75.00,
        valor: 150.00,
      },
    ],
  },
];

const mockProducts: BlingProduct[] = [
  {
    id: "P001",
    codigo: "PROD-001",
    descricao: "Notebook Dell Inspiron 15",
    preco: 250.00,
    estoqueAtual: 10,
  },
  {
    id: "P002",
    codigo: "PROD-002",
    descricao: "Mouse Logitech MX Master",
    preco: 75.00,
    estoqueAtual: 25,
  },
];

export class BlingService {
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.BLING_API_KEY || '';
  }

  async getOrders(): Promise<BlingOrder[]> {
    try {
      if (!this.apiKey) {
        logger.warn('Bling API key not configured, using mock data');
        return mockOrders;
      }

      // Real API call would go here
      // const response = await axios.get(`https://api.bling.com.br/Api/v3/pedidos`, {
      //   headers: { Authorization: `Bearer ${this.apiKey}` }
      // });
      // return response.data.data;

      logger.info('Using Bling mock data for orders');
      return mockOrders;
    } catch (error) {
      logger.error('Error fetching Bling orders', error);
      return mockOrders;
    }
  }

  async getProducts(): Promise<BlingProduct[]> {
    try {
      if (!this.apiKey) {
        logger.warn('Bling API key not configured, using mock data');
        return mockProducts;
      }

      // Real API call would go here
      logger.info('Using Bling mock data for products');
      return mockProducts;
    } catch (error) {
      logger.error('Error fetching Bling products', error);
      return mockProducts;
    }
  }
}
