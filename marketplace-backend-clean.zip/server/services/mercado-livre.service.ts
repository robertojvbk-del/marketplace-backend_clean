import { logger } from "../utils/logger";

export interface MercadoLivreOrder {
  id: string;
  date_created: string;
  total_amount: number;
  status: string;
  buyer: {
    nickname: string;
    email: string;
    phone?: {
      area_code: string;
      number: string;
    };
  };
  shipping?: {
    receiver_address?: {
      state?: {
        name: string;
      };
    };
  };
  order_items: {
    item: {
      id: string;
      title: string;
      seller_sku?: string;
    };
    quantity: number;
    unit_price: number;
    full_unit_price: number;
  }[];
}

export interface MercadoLivreProduct {
  id: string;
  title: string;
  seller_custom_field?: string;
  price: number;
  available_quantity: number;
}

const mockOrders: MercadoLivreOrder[] = [
  {
    id: "ML123456789",
    date_created: new Date().toISOString(),
    total_amount: 199.90,
    status: "paid",
    buyer: {
      nickname: "COMPRADOR789",
      email: "comprador@mercadolivre.com",
      phone: {
        area_code: "11",
        number: "987654321",
      },
    },
    shipping: {
      receiver_address: {
        state: {
          name: "São Paulo",
        },
      },
    },
    order_items: [
      {
        item: {
          id: "MLB001",
          title: "Fone de Ouvido Bluetooth",
          seller_sku: "FON-BT-001",
        },
        quantity: 1,
        unit_price: 199.90,
        full_unit_price: 199.90,
      },
    ],
  },
  {
    id: "ML987654321",
    date_created: new Date(Date.now() - 259200000).toISOString(),
    total_amount: 79.90,
    status: "delivered",
    buyer: {
      nickname: "CLIENTE456",
      email: "cliente@mercadolivre.com",
    },
    shipping: {
      receiver_address: {
        state: {
          name: "Rio de Janeiro",
        },
      },
    },
    order_items: [
      {
        item: {
          id: "MLB002",
          title: "Cabo USB-C Premium",
          seller_sku: "CAB-USC-002",
        },
        quantity: 2,
        unit_price: 39.95,
        full_unit_price: 39.95,
      },
    ],
  },
];

const mockProducts: MercadoLivreProduct[] = [
  {
    id: "MLB001",
    title: "Fone de Ouvido Bluetooth",
    seller_custom_field: "FON-BT-001",
    price: 199.90,
    available_quantity: 20,
  },
  {
    id: "MLB002",
    title: "Cabo USB-C Premium",
    seller_custom_field: "CAB-USC-002",
    price: 39.95,
    available_quantity: 50,
  },
];

export class MercadoLivreService {
  private clientId: string;
  private clientSecret: string;
  private accessToken: string;

  constructor() {
    this.clientId = process.env.MERCADO_LIVRE_CLIENT_ID || '';
    this.clientSecret = process.env.MERCADO_LIVRE_CLIENT_SECRET || '';
    this.accessToken = '';
  }

  async getOrders(): Promise<MercadoLivreOrder[]> {
    try {
      if (!this.clientId || !this.clientSecret) {
        logger.warn('Mercado Livre credentials not configured, using mock data');
        return mockOrders;
      }

      // Real API call would go here with OAuth token
      logger.info('Using Mercado Livre mock data for orders');
      return mockOrders;
    } catch (error) {
      logger.error('Error fetching Mercado Livre orders', error);
      return mockOrders;
    }
  }

  async getProducts(): Promise<MercadoLivreProduct[]> {
    try {
      if (!this.clientId || !this.clientSecret) {
        logger.warn('Mercado Livre credentials not configured, using mock data');
        return mockProducts;
      }

      logger.info('Using Mercado Livre mock data for products');
      return mockProducts;
    } catch (error) {
      logger.error('Error fetching Mercado Livre products', error);
      return mockProducts;
    }
  }
}
