import { logger } from "../utils/logger";

export interface ShopeeOrder {
  order_sn: string;
  create_time: number;
  total_amount: number;
  order_status: string;
  buyer_username: string;
  recipient_address: {
    name: string;
    phone: string;
    state?: string;
  };
  items: {
    item_id: string;
    item_name: string;
    item_sku: string;
    model_quantity_purchased: number;
    model_original_price: number;
  }[];
}

export interface ShopeeProduct {
  item_id: string;
  item_sku: string;
  item_name: string;
  price: number;
  stock: number;
}

const mockOrders: ShopeeOrder[] = [
  {
    order_sn: "SHP2024001",
    create_time: Date.now() / 1000,
    total_amount: 89.90,
    order_status: "READY_TO_SHIP",
    buyer_username: "comprador123",
    recipient_address: {
      name: "Carlos Oliveira",
      phone: "11987654321",
      state: "SP",
    },
    items: [
      {
        item_id: "SHP001",
        item_name: "Teclado Mecânico RGB",
        item_sku: "TEC-RGB-001",
        model_quantity_purchased: 1,
        model_original_price: 89.90,
      },
    ],
  },
  {
    order_sn: "SHP2024002",
    create_time: (Date.now() - 172800000) / 1000,
    total_amount: 45.50,
    order_status: "COMPLETED",
    buyer_username: "cliente456",
    recipient_address: {
      name: "Ana Paula",
      phone: "21998765432",
      state: "RJ",
    },
    items: [
      {
        item_id: "SHP002",
        item_name: "Mousepad Gamer",
        item_sku: "PAD-GMR-002",
        model_quantity_purchased: 1,
        model_original_price: 45.50,
      },
    ],
  },
];

const mockProducts: ShopeeProduct[] = [
  {
    item_id: "SHP001",
    item_sku: "TEC-RGB-001",
    item_name: "Teclado Mecânico RGB",
    price: 89.90,
    stock: 15,
  },
  {
    item_id: "SHP002",
    item_sku: "PAD-GMR-002",
    item_name: "Mousepad Gamer",
    price: 45.50,
    stock: 30,
  },
];

export class ShopeeService {
  private partnerId: string;
  private partnerKey: string;
  private shopId: string;

  constructor() {
    this.partnerId = process.env.SHOPEE_PARTNER_ID || '';
    this.partnerKey = process.env.SHOPEE_PARTNER_KEY || '';
    this.shopId = process.env.SHOPEE_SHOP_ID || '';
  }

  async getOrders(): Promise<ShopeeOrder[]> {
    try {
      if (!this.partnerId || !this.partnerKey) {
        logger.warn('Shopee credentials not configured, using mock data');
        return mockOrders;
      }

      // Real API call would go here with HMAC signature
      logger.info('Using Shopee mock data for orders');
      return mockOrders;
    } catch (error) {
      logger.error('Error fetching Shopee orders', error);
      return mockOrders;
    }
  }

  async getProducts(): Promise<ShopeeProduct[]> {
    try {
      if (!this.partnerId || !this.partnerKey) {
        logger.warn('Shopee credentials not configured, using mock data');
        return mockProducts;
      }

      logger.info('Using Shopee mock data for products');
      return mockProducts;
    } catch (error) {
      logger.error('Error fetching Shopee products', error);
      return mockProducts;
    }
  }
}
