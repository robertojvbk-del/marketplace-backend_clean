import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { BlingService } from "./services/bling.service";
import { ShopeeService } from "./services/shopee.service";
import { MercadoLivreService } from "./services/mercado-livre.service";
import { LojaIntegradaService } from "./services/loja-integrada.service";
import { normalizeSku, normalizeStatus } from "./utils/sku-normalizer";
import { logger } from "./utils/logger";
import { validatePrice, coerceMonetary } from "./utils/validation";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard metrics
  app.get("/api/dashboard/metrics", async (_req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json(metrics);
    } catch (error) {
      logger.error("Error fetching dashboard metrics", error);
      res.status(500).json({ error: "Failed to fetch dashboard metrics" });
    }
  });

  // Orders endpoints
  app.get("/api/orders", async (_req, res) => {
    try {
      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      logger.error("Error fetching orders", error);
      res.status(500).json({ error: "Failed to fetch orders" });
    }
  });

  app.get("/api/orders/recent", async (_req, res) => {
    try {
      const orders = await storage.getRecentOrders(10);
      res.json(orders);
    } catch (error) {
      logger.error("Error fetching recent orders", error);
      res.status(500).json({ error: "Failed to fetch recent orders" });
    }
  });

  app.get("/api/orders/:id", async (req, res) => {
    try {
      const order = await storage.getOrder(req.params.id);
      if (!order) {
        return res.status(404).json({ error: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      logger.error("Error fetching order", error);
      res.status(500).json({ error: "Failed to fetch order" });
    }
  });

  // Sync orders from all marketplaces
  app.post("/api/orders/sync", async (_req, res) => {
    try {
      logger.info("Starting order sync from all marketplaces");
      
      const services = {
        bling: new BlingService(),
        shopee: new ShopeeService(),
        mercado_livre: new MercadoLivreService(),
        loja_integrada: new LojaIntegradaService(),
      };

      let syncedCount = 0;

      // Sync Bling orders
      const blingOrders = await services.bling.getOrders();
      for (const blingOrder of blingOrders) {
        const existing = await storage.getOrderByExternalId(blingOrder.numero, 'bling');
        if (existing) continue;

        // Create or get customer
        let customer = await storage.getCustomerByEmail(blingOrder.cliente.email || '');
        if (!customer) {
          customer = await storage.createCustomer({
            name: blingOrder.cliente.nome,
            email: blingOrder.cliente.email,
            phone: blingOrder.cliente.telefone,
            document: blingOrder.cliente.documento,
            state: blingOrder.cliente.uf,
          });
        }

        // Create order
        const orderTotal = coerceMonetary(blingOrder.total);
        if (orderTotal === null) {
          logger.warn(`Invalid order total for Bling order ${blingOrder.numero}: ${blingOrder.total}`);
          continue;
        }
        
        const order = await storage.createOrder({
          marketplace: 'bling',
          externalOrderId: blingOrder.numero,
          customerId: customer.id,
          orderDate: new Date(blingOrder.dataVenda),
          totalAmount: orderTotal,
          status: normalizeStatus(blingOrder.situacao, 'bling'),
        });

        // Create order items
        for (const item of blingOrder.itens) {
          const skuNorm = normalizeSku(item.produto.codigo);
          let product = await storage.getProductBySku(skuNorm, 'bling');
          
          const validPrice = validatePrice(item.valorunidade);
          if (validPrice === null) {
            logger.warn(`Invalid price for Bling product ${item.produto.codigo}: ${item.valorunidade}`);
            continue;
          }
          
          if (!product) {
            product = await storage.createProduct({
              marketplace: 'bling',
              externalProductId: item.produto.id,
              sku: item.produto.codigo,
              skuNormalizado: skuNorm,
              name: item.produto.descricao,
              price: validPrice.toString(),
              stock: 0,
            });
          } else {
            await storage.updateProduct(product.id, {
              price: validPrice.toString(),
            });
          }

          const itemUnitPrice = coerceMonetary(item.valorunidade);
          const itemTotalPrice = coerceMonetary(item.valor);
          if (itemUnitPrice === null || itemTotalPrice === null) {
            logger.warn(`Invalid item prices for Bling product ${item.produto.codigo}`);
            continue;
          }
          
          await storage.createOrderItem({
            orderId: order.id,
            productId: product.id,
            quantity: item.quantidade,
            unitPrice: itemUnitPrice,
            totalPrice: itemTotalPrice,
            skuNormalizado: skuNorm,
          });
        }
        syncedCount++;
      }

      // Sync Shopee orders
      const shopeeOrders = await services.shopee.getOrders();
      for (const shopeeOrder of shopeeOrders) {
        const existing = await storage.getOrderByExternalId(shopeeOrder.order_sn, 'shopee');
        if (existing) continue;

        const customerEmail = shopeeOrder.buyer_username + '@shopee.com';
        let customer = await storage.getCustomerByEmail(customerEmail);
        if (!customer) {
          customer = await storage.createCustomer({
            name: shopeeOrder.recipient_address.name,
            email: customerEmail,
            phone: shopeeOrder.recipient_address.phone,
            state: shopeeOrder.recipient_address.state || 'SP',
          });
        }

        const orderTotal = coerceMonetary(shopeeOrder.total_amount);
        if (orderTotal === null) {
          logger.warn(`Invalid order total for Shopee order ${shopeeOrder.order_sn}: ${shopeeOrder.total_amount}`);
          continue;
        }
        
        const order = await storage.createOrder({
          marketplace: 'shopee',
          externalOrderId: shopeeOrder.order_sn,
          customerId: customer.id,
          orderDate: new Date(shopeeOrder.create_time * 1000),
          totalAmount: orderTotal,
          status: normalizeStatus(shopeeOrder.order_status, 'shopee'),
        });

        for (const item of shopeeOrder.items) {
          const skuNorm = normalizeSku(item.item_sku);
          let product = await storage.getProductBySku(skuNorm, 'shopee');
          
          const validPrice = validatePrice(item.model_original_price);
          if (validPrice === null) {
            logger.warn(`Invalid price for Shopee product ${item.item_sku}: ${item.model_original_price}`);
            continue;
          }
          
          if (!product) {
            product = await storage.createProduct({
              marketplace: 'shopee',
              externalProductId: item.item_id,
              sku: item.item_sku,
              skuNormalizado: skuNorm,
              name: item.item_name,
              price: validPrice.toString(),
              stock: 0,
            });
          } else {
            await storage.updateProduct(product.id, {
              price: validPrice.toString(),
            });
          }

          const itemUnitPrice = coerceMonetary(item.model_original_price);
          const itemTotalPrice = coerceMonetary(item.model_original_price * item.model_quantity_purchased);
          if (itemUnitPrice === null || itemTotalPrice === null) {
            logger.warn(`Invalid item prices for Shopee product ${item.item_sku}`);
            continue;
          }
          
          await storage.createOrderItem({
            orderId: order.id,
            productId: product.id,
            quantity: item.model_quantity_purchased,
            unitPrice: itemUnitPrice,
            totalPrice: itemTotalPrice,
            skuNormalizado: skuNorm,
          });
        }
        syncedCount++;
      }

      // Sync Mercado Livre orders
      const mlOrders = await services.mercado_livre.getOrders();
      for (const mlOrder of mlOrders) {
        const existing = await storage.getOrderByExternalId(mlOrder.id, 'mercado_livre');
        if (existing) continue;

        let customer = await storage.getCustomerByEmail(mlOrder.buyer.email);
        if (!customer) {
          const stateName = mlOrder.shipping?.receiver_address?.state?.name;
          const stateCode = stateName ? (stateName.substring(0, 2).toUpperCase()) : 'SP';
          customer = await storage.createCustomer({
            name: mlOrder.buyer.nickname,
            email: mlOrder.buyer.email,
            phone: mlOrder.buyer.phone ? `${mlOrder.buyer.phone.area_code}${mlOrder.buyer.phone.number}` : undefined,
            state: stateCode,
          });
        }

        const orderTotal = coerceMonetary(mlOrder.total_amount);
        if (orderTotal === null) {
          logger.warn(`Invalid order total for Mercado Livre order ${mlOrder.id}: ${mlOrder.total_amount}`);
          continue;
        }
        
        const order = await storage.createOrder({
          marketplace: 'mercado_livre',
          externalOrderId: mlOrder.id,
          customerId: customer.id,
          orderDate: new Date(mlOrder.date_created),
          totalAmount: orderTotal,
          status: normalizeStatus(mlOrder.status, 'mercado_livre'),
        });

        for (const item of mlOrder.order_items) {
          const skuNorm = normalizeSku(item.item.seller_sku || item.item.id);
          let product = await storage.getProductBySku(skuNorm, 'mercado_livre');
          
          const validPrice = validatePrice(item.unit_price);
          if (validPrice === null) {
            logger.warn(`Invalid price for Mercado Livre product ${item.item.seller_sku || item.item.id}: ${item.unit_price}`);
            continue;
          }
          
          if (!product) {
            product = await storage.createProduct({
              marketplace: 'mercado_livre',
              externalProductId: item.item.id,
              sku: item.item.seller_sku || item.item.id,
              skuNormalizado: skuNorm,
              name: item.item.title,
              price: validPrice.toString(),
              stock: 0,
            });
          } else {
            await storage.updateProduct(product.id, {
              price: validPrice.toString(),
            });
          }

          const itemUnitPrice = coerceMonetary(item.unit_price);
          const itemTotalPrice = coerceMonetary(item.unit_price * item.quantity);
          if (itemUnitPrice === null || itemTotalPrice === null) {
            logger.warn(`Invalid item prices for Mercado Livre product ${item.item.seller_sku || item.item.id}`);
            continue;
          }
          
          await storage.createOrderItem({
            orderId: order.id,
            productId: product.id,
            quantity: item.quantity,
            unitPrice: itemUnitPrice,
            totalPrice: itemTotalPrice,
            skuNormalizado: skuNorm,
          });
        }
        syncedCount++;
      }

      // Sync Loja Integrada orders
      const liOrders = await services.loja_integrada.getOrders();
      for (const liOrder of liOrders) {
        const existing = await storage.getOrderByExternalId(liOrder.numero, 'loja_integrada');
        if (existing) continue;

        let customer = await storage.getCustomerByEmail(liOrder.cliente.email);
        if (!customer) {
          customer = await storage.createCustomer({
            name: liOrder.cliente.nome,
            email: liOrder.cliente.email,
            phone: liOrder.cliente.telefone_celular,
            document: liOrder.cliente.cpf,
            state: liOrder.cliente.endereco_entrega?.estado,
          });
        }

        const orderTotal = coerceMonetary(liOrder.valor_total);
        if (orderTotal === null) {
          logger.warn(`Invalid order total for Loja Integrada order ${liOrder.numero}: ${liOrder.valor_total}`);
          continue;
        }
        
        const order = await storage.createOrder({
          marketplace: 'loja_integrada',
          externalOrderId: liOrder.numero,
          customerId: customer.id,
          orderDate: new Date(liOrder.data_criacao),
          totalAmount: orderTotal,
          status: normalizeStatus(liOrder.situacao.nome, 'loja_integrada'),
        });

        for (const item of liOrder.itens) {
          const skuNorm = normalizeSku(item.produto.sku);
          let product = await storage.getProductBySku(skuNorm, 'loja_integrada');
          
          const validPrice = validatePrice(item.preco_venda);
          if (validPrice === null) {
            logger.warn(`Invalid price for Loja Integrada product ${item.produto.sku}: ${item.preco_venda}`);
            continue;
          }
          
          if (!product) {
            product = await storage.createProduct({
              marketplace: 'loja_integrada',
              externalProductId: item.produto.id,
              sku: item.produto.sku,
              skuNormalizado: skuNorm,
              name: item.produto.nome,
              price: validPrice.toString(),
              stock: 0,
            });
          } else {
            await storage.updateProduct(product.id, {
              price: validPrice.toString(),
            });
          }

          const itemUnitPrice = coerceMonetary(item.preco_venda);
          const itemTotalPrice = coerceMonetary(item.subtotal);
          if (itemUnitPrice === null || itemTotalPrice === null) {
            logger.warn(`Invalid item prices for Loja Integrada product ${item.produto.sku}`);
            continue;
          }
          
          await storage.createOrderItem({
            orderId: order.id,
            productId: product.id,
            quantity: item.quantidade,
            unitPrice: itemUnitPrice,
            totalPrice: itemTotalPrice,
            skuNormalizado: skuNorm,
          });
        }
        syncedCount++;
      }

      logger.info(`Order sync completed. Synced ${syncedCount} new orders`);
      res.json({ success: true, syncedCount });
    } catch (error) {
      logger.error("Error syncing orders", error);
      res.status(500).json({ error: "Failed to sync orders" });
    }
  });

  // Products endpoints
  app.get("/api/products", async (_req, res) => {
    try {
      const products = await storage.getAllProducts();
      res.json(products);
    } catch (error) {
      logger.error("Error fetching products", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      logger.error("Error fetching product", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  // Customers endpoints
  app.get("/api/customers", async (_req, res) => {
    try {
      const customers = await storage.getCustomersWithStats();
      res.json(customers);
    } catch (error) {
      logger.error("Error fetching customers", error);
      res.status(500).json({ error: "Failed to fetch customers" });
    }
  });

  app.get("/api/customers/:id", async (req, res) => {
    try {
      const customer = await storage.getCustomer(req.params.id);
      if (!customer) {
        return res.status(404).json({ error: "Customer not found" });
      }
      res.json(customer);
    } catch (error) {
      logger.error("Error fetching customer", error);
      res.status(500).json({ error: "Failed to fetch customer" });
    }
  });

  // Analytics endpoints
  app.get("/api/analytics/faturamento", async (_req, res) => {
    try {
      const data = await storage.getFaturamento();
      res.json(data);
    } catch (error) {
      logger.error("Error fetching faturamento", error);
      res.status(500).json({ error: "Failed to fetch faturamento" });
    }
  });

  app.get("/api/analytics/top-produtos", async (_req, res) => {
    try {
      const data = await storage.getTopProdutos(10);
      res.json(data);
    } catch (error) {
      logger.error("Error fetching top produtos", error);
      res.status(500).json({ error: "Failed to fetch top produtos" });
    }
  });

  app.get("/api/analytics/menos-vendidos", async (_req, res) => {
    try {
      const data = await storage.getMenosVendidos(10);
      res.json(data);
    } catch (error) {
      logger.error("Error fetching menos vendidos", error);
      res.status(500).json({ error: "Failed to fetch menos vendidos" });
    }
  });

  app.get("/api/analytics/vendas-estado", async (_req, res) => {
    try {
      const data = await storage.getVendasPorEstado();
      res.json(data);
    } catch (error) {
      logger.error("Error fetching vendas por estado", error);
      res.status(500).json({ error: "Failed to fetch vendas por estado" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
