/**
 * Normalizes SKU by removing special characters and converting to uppercase
 * Example: "ABC-123.XYZ" -> "ABC123XYZ"
 */
export function normalizeSku(sku: string): string {
  return sku
    .replace(/[^a-zA-Z0-9]/g, '')
    .toUpperCase()
    .trim();
}

/**
 * Normalizes order status across different marketplace formats
 */
export function normalizeStatus(status: string, marketplace: string): string {
  const statusLower = status.toLowerCase();
  
  // Map various marketplace statuses to our standard statuses
  if (statusLower.includes('pend') || statusLower.includes('aguard')) {
    return 'pending';
  }
  if (statusLower.includes('process') || statusLower.includes('prepar')) {
    return 'processing';
  }
  if (statusLower.includes('envi') || statusLower.includes('ship') || statusLower.includes('transito')) {
    return 'shipped';
  }
  if (statusLower.includes('entreg') || statusLower.includes('complet') || statusLower.includes('deliver')) {
    return 'delivered';
  }
  if (statusLower.includes('cancel') || statusLower.includes('reject')) {
    return 'cancelled';
  }
  
  return 'pending'; // Default fallback
}

/**
 * Generates a unique external ID for mapping
 */
export function generateExternalId(marketplace: string, id: string | number): string {
  return `${marketplace.toUpperCase()}_${id}`;
}
