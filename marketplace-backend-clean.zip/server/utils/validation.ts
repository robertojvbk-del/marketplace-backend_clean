import { z } from "zod";

/**
 * Validates and parses a numeric price value
 * Accepts valid numbers including 0, rejects NaN and invalid strings
 */
export function validatePrice(value: any): number | null {
  const result = z.coerce.number().safeParse(value);
  if (result.success && !isNaN(result.data)) {
    return result.data;
  }
  return null;
}

/**
 * Validates and coerces monetary values (prices, totals, etc.)
 * Uses Zod to ensure only valid non-negative numbers are persisted
 * Returns null for invalid values
 */
export function coerceMonetary(value: any): string | null {
  const result = z.coerce.number().nonnegative().safeParse(value);
  if (result.success && !isNaN(result.data)) {
    return result.data.toString();
  }
  return null;
}
