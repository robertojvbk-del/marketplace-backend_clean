import { Badge } from "@/components/ui/badge";

type Marketplace = "bling" | "shopee" | "mercado_livre" | "loja_integrada";

interface MarketplaceBadgeProps {
  marketplace: Marketplace;
}

const marketplaceConfig: Record<Marketplace, { label: string; className: string }> = {
  bling: {
    label: "Bling",
    className: "bg-blue-100 text-blue-800 border-blue-200 dark:bg-blue-950 dark:text-blue-200 dark:border-blue-800",
  },
  shopee: {
    label: "Shopee",
    className: "bg-orange-100 text-orange-800 border-orange-200 dark:bg-orange-950 dark:text-orange-200 dark:border-orange-800",
  },
  mercado_livre: {
    label: "Mercado Livre",
    className: "bg-yellow-100 text-yellow-800 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-200 dark:border-yellow-800",
  },
  loja_integrada: {
    label: "Loja Integrada",
    className: "bg-purple-100 text-purple-800 border-purple-200 dark:bg-purple-950 dark:text-purple-200 dark:border-purple-800",
  },
};

export function MarketplaceBadge({ marketplace }: MarketplaceBadgeProps) {
  const config = marketplaceConfig[marketplace];

  return (
    <Badge 
      variant="outline" 
      className={config.className}
      data-testid={`badge-marketplace-${marketplace}`}
    >
      {config.label}
    </Badge>
  );
}
