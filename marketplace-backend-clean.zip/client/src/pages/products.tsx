import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MarketplaceBadge } from "@/components/marketplace-badge";
import { Package, Search } from "lucide-react";
import type { Product } from "@shared/schema";

export default function Products() {
  const [searchTerm, setSearchTerm] = useState("");
  const [marketplaceFilter, setMarketplaceFilter] = useState<string>("all");

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const filteredProducts = products?.filter((product) => {
    const matchesSearch = 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.skuNormalizado.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesMarketplace = marketplaceFilter === "all" || product.marketplace === marketplaceFilter;
    return matchesSearch && matchesMarketplace;
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight" data-testid="text-page-title">
          Produtos
        </h1>
        <p className="text-sm text-muted-foreground">
          Visualize e gerencie produtos de todos os marketplaces
        </p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar por nome, SKU..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
            data-testid="input-search-products"
          />
        </div>
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
          <label className="text-sm font-medium">Marketplace:</label>
          <Select value={marketplaceFilter} onValueChange={setMarketplaceFilter}>
            <SelectTrigger className="w-full sm:w-[180px]" data-testid="select-marketplace-filter">
              <SelectValue placeholder="Todos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="bling">Bling</SelectItem>
              <SelectItem value="shopee">Shopee</SelectItem>
              <SelectItem value="mercado_livre">Mercado Livre</SelectItem>
              <SelectItem value="loja_integrada">Loja Integrada</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold">
            Lista de Produtos ({filteredProducts?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !filteredProducts || filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Package className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum produto encontrado</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                {searchTerm || marketplaceFilter !== "all"
                  ? "Tente ajustar os filtros de busca."
                  : "Os produtos aparecerão aqui assim que forem sincronizados."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">SKU</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Nome</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Marketplace</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Preço</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Estoque</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Última Sync</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredProducts.map((product) => (
                    <TableRow key={product.id} className="hover-elevate" data-testid={`row-product-${product.id}`}>
                      <TableCell className="font-mono text-sm">{product.skuNormalizado}</TableCell>
                      <TableCell className="font-medium">{product.name}</TableCell>
                      <TableCell>
                        <MarketplaceBadge marketplace={product.marketplace as any} />
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        R$ {parseFloat(product.price.toString()).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-right">{product.stock ?? 0}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(product.lastSync).toLocaleDateString('pt-BR')}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
