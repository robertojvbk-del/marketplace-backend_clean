import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Users, Search } from "lucide-react";
import type { Customer } from "@shared/schema";

interface CustomerWithStats extends Customer {
  ordersCount: number;
  totalSpent: string;
  lastOrderDate: string | null;
}

export default function Customers() {
  const [searchTerm, setSearchTerm] = useState("");

  const { data: customers, isLoading } = useQuery<CustomerWithStats[]>({
    queryKey: ["/api/customers"],
  });

  const filteredCustomers = customers?.filter((customer) => {
    const matchesSearch = 
      customer.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.document?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight" data-testid="text-page-title">
          Clientes
        </h1>
        <p className="text-sm text-muted-foreground">
          Gerencie informações de clientes de todos os marketplaces
        </p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Buscar por nome, email ou documento..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
          data-testid="input-search-customers"
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold">
            Lista de Clientes ({filteredCustomers?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !filteredCustomers || filteredCustomers.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum cliente encontrado</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                {searchTerm
                  ? "Tente ajustar o termo de busca."
                  : "Os clientes aparecerão aqui assim que realizarem pedidos."}
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Nome</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Email</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Telefone</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Estado</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Pedidos</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Total Gasto</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Último Pedido</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.map((customer) => (
                    <TableRow key={customer.id} className="hover-elevate" data-testid={`row-customer-${customer.id}`}>
                      <TableCell className="font-medium">{customer.name}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{customer.email || "N/A"}</TableCell>
                      <TableCell className="text-sm">{customer.phone || "N/A"}</TableCell>
                      <TableCell className="text-sm">{customer.state || "N/A"}</TableCell>
                      <TableCell className="text-right">{customer.ordersCount}</TableCell>
                      <TableCell className="text-right font-medium">
                        R$ {parseFloat(customer.totalSpent).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {customer.lastOrderDate 
                          ? new Date(customer.lastOrderDate).toLocaleDateString('pt-BR')
                          : "N/A"}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
