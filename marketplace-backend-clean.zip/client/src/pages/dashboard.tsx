import { useQuery } from "@tanstack/react-query";
import { MetricCard } from "@/components/metric-card";
import { MarketplaceBadge } from "@/components/marketplace-badge";
import { StatusBadge } from "@/components/status-badge";
import { DollarSign, ShoppingCart, Package, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import type { OrderWithDetails } from "@shared/schema";

interface DashboardMetrics {
  totalRevenue: number;
  ordersToday: number;
  activeProducts: number;
  totalCustomers: number;
}

export default function Dashboard() {
  const { data: metrics, isLoading: metricsLoading } = useQuery<DashboardMetrics>({
    queryKey: ["/api/dashboard/metrics"],
  });

  const { data: recentOrders, isLoading: ordersLoading } = useQuery<OrderWithDetails[]>({
    queryKey: ["/api/orders/recent"],
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight" data-testid="text-page-title">
          Dashboard
        </h1>
        <p className="text-sm text-muted-foreground">
          Visão geral consolidada de todos os marketplaces
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Faturamento Total"
          value={metrics ? `R$ ${metrics.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : "R$ 0,00"}
          icon={DollarSign}
          isLoading={metricsLoading}
        />
        <MetricCard
          title="Pedidos Hoje"
          value={metrics?.ordersToday ?? 0}
          icon={ShoppingCart}
          isLoading={metricsLoading}
        />
        <MetricCard
          title="Produtos Ativos"
          value={metrics?.activeProducts ?? 0}
          icon={Package}
          isLoading={metricsLoading}
        />
        <MetricCard
          title="Total de Clientes"
          value={metrics?.totalCustomers ?? 0}
          icon={Users}
          isLoading={metricsLoading}
        />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
          <CardTitle className="text-xl font-semibold">Pedidos Recentes</CardTitle>
        </CardHeader>
        <CardContent>
          {ordersLoading ? (
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !recentOrders || recentOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum pedido encontrado</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Os pedidos aparecerão aqui assim que forem sincronizados dos marketplaces.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">ID</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Marketplace</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Cliente</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Data</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Valor</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {recentOrders.slice(0, 10).map((order) => (
                    <TableRow key={order.id} className="hover-elevate" data-testid={`row-order-${order.id}`}>
                      <TableCell className="font-mono text-sm">
                        {order.externalOrderId.substring(0, 8)}
                      </TableCell>
                      <TableCell>
                        <MarketplaceBadge marketplace={order.marketplace as any} />
                      </TableCell>
                      <TableCell>{order.customer?.name || "N/A"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(order.orderDate).toLocaleDateString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        R$ {parseFloat(order.totalAmount.toString()).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={order.status as any} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
