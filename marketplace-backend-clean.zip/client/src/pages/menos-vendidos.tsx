import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { MarketplaceBadge } from "@/components/marketplace-badge";
import { TrendingDown, AlertTriangle } from "lucide-react";

interface LowProduct {
  productId: string;
  productName: string;
  marketplace: string;
  unitsSold: number;
  revenue: number;
}

export default function MenosVendidos() {
  const { data: products, isLoading } = useQuery<LowProduct[]>({
    queryKey: ["/api/analytics/menos-vendidos"],
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight flex items-center gap-3" data-testid="text-page-title">
          <TrendingDown className="h-8 w-8 text-orange-600" />
          10 Produtos Menos Vendidos
        </h1>
        <p className="text-sm text-muted-foreground">
          Produtos que precisam de atenção ou estratégias de venda
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-orange-600" />
            Produtos com Baixa Performance
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !products || products.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <TrendingDown className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum dado disponível</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Os produtos com menor performance aparecerão aqui assim que houver dados suficientes.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide w-16">#</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Produto</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Marketplace</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Unidades Vendidas</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Receita Gerada</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {products.slice(0, 10).map((product, index) => (
                    <TableRow 
                      key={product.productId} 
                      className="hover-elevate" 
                      data-testid={`row-product-${index + 1}`}
                    >
                      <TableCell className="font-bold text-lg text-muted-foreground">
                        {index + 1}
                      </TableCell>
                      <TableCell className="font-medium">{product.productName}</TableCell>
                      <TableCell>
                        <MarketplaceBadge marketplace={product.marketplace as any} />
                      </TableCell>
                      <TableCell className="text-right font-semibold text-orange-600 dark:text-orange-400">
                        {product.unitsSold.toLocaleString('pt-BR')}
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        R$ {product.revenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
