import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MarketplaceBadge } from "@/components/marketplace-badge";
import { StatusBadge } from "@/components/status-badge";
import { RefreshCw, ShoppingCart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { OrderWithDetails } from "@shared/schema";

export default function Orders() {
  const [marketplaceFilter, setMarketplaceFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const { toast } = useToast();

  const { data: orders, isLoading } = useQuery<OrderWithDetails[]>({
    queryKey: ["/api/orders"],
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/orders/sync", {});
    },
    onSuccess: (data: any) => {
      // Invalidate all data queries to refresh the entire UI
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/orders/recent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      queryClient.invalidateQueries({ queryKey: ["/api/customers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/faturamento"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/top-produtos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/menos-vendidos"] });
      queryClient.invalidateQueries({ queryKey: ["/api/analytics/vendas-estado"] });
      toast({
        title: "Sincronização concluída",
        description: `${data.syncedCount} novos pedidos foram sincronizados.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Erro na sincronização",
        description: error.message || "Não foi possível sincronizar os pedidos.",
        variant: "destructive",
      });
    },
  });

  const handleSync = () => {
    syncMutation.mutate();
  };

  const filteredOrders = orders?.filter((order) => {
    const matchesMarketplace = marketplaceFilter === "all" || order.marketplace === marketplaceFilter;
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    return matchesMarketplace && matchesStatus;
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-col gap-2">
          <h1 className="text-3xl font-bold leading-tight" data-testid="text-page-title">
            Pedidos
          </h1>
          <p className="text-sm text-muted-foreground">
            Gerencie todos os pedidos de diferentes marketplaces
          </p>
        </div>
        <Button onClick={handleSync} disabled={syncMutation.isPending} data-testid="button-sync-orders">
          <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
          {syncMutation.isPending ? 'Sincronizando...' : 'Sincronizar'}
        </Button>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
          <label className="text-sm font-medium">Marketplace:</label>
          <Select value={marketplaceFilter} onValueChange={setMarketplaceFilter}>
            <SelectTrigger className="w-full sm:w-[180px]" data-testid="select-marketplace-filter">
              <SelectValue placeholder="Todos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="bling">Bling</SelectItem>
              <SelectItem value="shopee">Shopee</SelectItem>
              <SelectItem value="mercado_livre">Mercado Livre</SelectItem>
              <SelectItem value="loja_integrada">Loja Integrada</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-4">
          <label className="text-sm font-medium">Status:</label>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full sm:w-[180px]" data-testid="select-status-filter">
              <SelectValue placeholder="Todos" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="processing">Processando</SelectItem>
              <SelectItem value="shipped">Enviado</SelectItem>
              <SelectItem value="delivered">Entregue</SelectItem>
              <SelectItem value="cancelled">Cancelado</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold">
            Lista de Pedidos ({filteredOrders?.length ?? 0})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !filteredOrders || filteredOrders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum pedido encontrado</h3>
              <p className="text-sm text-muted-foreground max-w-sm mb-4">
                Não há pedidos que correspondam aos filtros selecionados.
              </p>
              <Button onClick={handleSync} variant="outline" data-testid="button-sync-empty">
                <RefreshCw className="h-4 w-4 mr-2" />
                Sincronizar Pedidos
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">ID Externo</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Marketplace</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Cliente</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Data</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Valor Total</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders.map((order) => (
                    <TableRow key={order.id} className="hover-elevate" data-testid={`row-order-${order.id}`}>
                      <TableCell className="font-mono text-sm">{order.externalOrderId}</TableCell>
                      <TableCell>
                        <MarketplaceBadge marketplace={order.marketplace as any} />
                      </TableCell>
                      <TableCell>{order.customer?.name || "N/A"}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {new Date(order.orderDate).toLocaleDateString('pt-BR', {
                          day: '2-digit',
                          month: '2-digit',
                          year: 'numeric',
                        })}
                      </TableCell>
                      <TableCell className="text-right font-medium">
                        R$ {parseFloat(order.totalAmount.toString()).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell>
                        <StatusBadge status={order.status as any} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
