import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { MapPin, TrendingUp } from "lucide-react";

interface SalesByState {
  state: string;
  ordersCount: number;
  totalRevenue: number;
  customersCount: number;
}

export default function VendasEstado() {
  const { data: salesByState, isLoading } = useQuery<SalesByState[]>({
    queryKey: ["/api/analytics/vendas-estado"],
  });

  const topStates = salesByState?.slice(0, 5);

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight flex items-center gap-3" data-testid="text-page-title">
          <MapPin className="h-8 w-8 text-blue-600" />
          Vendas por Estado
        </h1>
        <p className="text-sm text-muted-foreground">
          Análise geográfica de vendas em todo o Brasil
        </p>
      </div>

      {topStates && topStates.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {topStates.map((state, index) => (
            <Card key={state.state} data-testid={`card-top-state-${index + 1}`}>
              <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {index + 1}º - {state.state || "N/A"}
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  R$ {state.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {state.ordersCount} pedidos · {state.customersCount} clientes
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Detalhamento por Estado
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(10)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !salesByState || salesByState.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <MapPin className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum dado disponível</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Os dados de vendas por estado aparecerão aqui assim que houver pedidos com informações de localização.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Estado</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Pedidos</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Clientes</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Receita Total</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Ticket Médio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {salesByState.map((state) => (
                    <TableRow 
                      key={state.state} 
                      className="hover-elevate" 
                      data-testid={`row-state-${state.state}`}
                    >
                      <TableCell className="font-medium">{state.state || "N/A"}</TableCell>
                      <TableCell className="text-right">{state.ordersCount}</TableCell>
                      <TableCell className="text-right">{state.customersCount}</TableCell>
                      <TableCell className="text-right font-medium text-lg">
                        R$ {state.totalRevenue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        R$ {(state.totalRevenue / state.ordersCount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
