import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { MarketplaceBadge } from "@/components/marketplace-badge";
import { DollarSign, TrendingUp } from "lucide-react";

interface FaturamentoData {
  total: number;
  byMarketplace: {
    marketplace: string;
    total: number;
    ordersCount: number;
  }[];
}

export default function Faturamento() {
  const { data, isLoading } = useQuery<FaturamentoData>({
    queryKey: ["/api/analytics/faturamento"],
  });

  return (
    <div className="flex flex-col gap-6 p-4 md:p-6 lg:p-8">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold leading-tight" data-testid="text-page-title">
          Faturamento
        </h1>
        <p className="text-sm text-muted-foreground">
          Análise consolidada de receita por marketplace
        </p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
          <CardTitle className="text-sm font-medium text-muted-foreground">
            Faturamento Total Consolidado
          </CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Skeleton className="h-12 w-64" />
          ) : (
            <div className="text-4xl font-bold" data-testid="text-total-revenue">
              R$ {data?.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 }) ?? "0,00"}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-semibold flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Faturamento por Marketplace
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !data?.byMarketplace || data.byMarketplace.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <DollarSign className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum dado disponível</h3>
              <p className="text-sm text-muted-foreground max-w-sm">
                Os dados de faturamento aparecerão aqui assim que houver pedidos sincronizados.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-xs font-medium uppercase tracking-wide">Marketplace</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Pedidos</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Faturamento</TableHead>
                    <TableHead className="text-xs font-medium uppercase tracking-wide text-right">Ticket Médio</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.byMarketplace.map((item) => (
                    <TableRow key={item.marketplace} className="hover-elevate" data-testid={`row-marketplace-${item.marketplace}`}>
                      <TableCell>
                        <MarketplaceBadge marketplace={item.marketplace as any} />
                      </TableCell>
                      <TableCell className="text-right">{item.ordersCount}</TableCell>
                      <TableCell className="text-right font-medium text-lg">
                        R$ {item.total.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                      <TableCell className="text-right text-muted-foreground">
                        R$ {(item.total / item.ordersCount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
